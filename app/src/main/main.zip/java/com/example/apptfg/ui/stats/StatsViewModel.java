package com.example.apptfg.ui.stats;
import android.app.Application;import androidx.annotation.NonNull;import androidx.lifecycle.AndroidViewModel;import androidx.lifecycle.LiveData;import com.example.apptfg.data.local.AppDatabase;import com.example.apptfg.data.local.dao.PuntosDao;import com.example.apptfg.data.local.entities.Puntos;
public class StatsViewModel extends AndroidViewModel {
    private final PuntosDao puntosDao; private final LiveData<Puntos> puntosLive;
    public StatsViewModel(@NonNull Application application) {
        super(application);
        puntosDao = AppDatabase.getInstance(application).puntosDao();
        puntosLive = puntosDao.obtenerPuntosLive();
    }
    public LiveData<Puntos> getPuntosLive() { return puntosLive; }
}