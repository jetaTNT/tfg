package com.example.apptfg.ui.lector;
import android.app.Application;import androidx.annotation.NonNull;import androidx.lifecycle.AndroidViewModel;import androidx.lifecycle.LiveData;import androidx.lifecycle.MutableLiveData;import com.example.apptfg.data.model.Libro;import com.example.apptfg.data.model.Pagina;import com.example.apptfg.data.local.AppDatabase;import com.example.apptfg.data.local.dao.PuntosDao;import com.example.apptfg.data.local.entities.Puntos;import com.example.apptfg.data.model.Opcion;import com.example.apptfg.repository.LibroRepository;import java.util.concurrent.ExecutorService;import java.util.concurrent.Executors;
public class ReaderViewModel extends AndroidViewModel {
    private final LibroRepository libroRepo; private final PuntosDao puntosDao; private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final MutableLiveData<Pagina> paginaActual = new MutableLiveData<>(); private Libro libro; private int indexPagina;
    public ReaderViewModel(@NonNull Application application) {
        super(application);
        libroRepo = LibroRepository.getInstance(application);
        puntosDao = AppDatabase.getInstance(application).puntosDao();
    }
    public void init(int libroId) {
        executor.execute(() -> {
            libro = libroRepo.getLibroPorId(libroId);
            if (libro!=null && !libro.getPaginas().isEmpty()) { indexPagina = 0; paginaActual.postValue(libro.getPaginas().get(indexPagina)); }
        });
    }
    public LiveData<Pagina> getPaginaActual() { return paginaActual; }
    public void elegirOpcion(Opcion opcion) {
        executor.execute(() -> {
            int siguienteId = opcion.getSiguientePaginaId();
            for (int i=0; i<libro.getPaginas().size(); i++) {
                if (libro.getPaginas().get(i).getId() == siguienteId) {
                    indexPagina = i; paginaActual.postValue(libro.getPaginas().get(i)); return;
                }
            }
        });
    }
    public void registrarPaginaFinal(int puntosGanados) {
        executor.execute(() -> {
            Puntos pts = puntosDao.obtenerPuntosSincrono();
            if (pts!=null) { pts.setCantidad(pts.getCantidad()+puntosGanados); puntosDao.updatePuntos(pts); }
        });
    }
}