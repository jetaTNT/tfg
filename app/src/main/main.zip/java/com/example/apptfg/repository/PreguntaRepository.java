package com.example.apptfg.repository;
import com.example.apptfg.data.model.Pregunta;import java.util.ArrayList;import java.util.List;
public class PreguntaRepository {
    private static PreguntaRepository INSTANCE;
    private PreguntaRepository() {}
    public static synchronized PreguntaRepository getInstance() {
        if (INSTANCE == null) { INSTANCE = new PreguntaRepository(); }
        return INSTANCE;
    }
    public List<Pregunta> getPreguntasParaPaginaFinal(int libroId, int paginaFinalId) {
        List<Pregunta> lista = new ArrayList<>();
        lista.add(new Pregunta(1,"¿Qué vio Leo entre los árboles?",List.of("Una cabaña","Una luz misteriosa","Un dragón","Un río"),1,"Leo vio una luz misteriosa que provenía de una cabaña."));
        lista.add(new Pregunta(2,"¿Con quién hizo amistad Leo?",List.of("Con el zorro","Con un ciervo","Con un búho","Con un oso"),0,"Leo hizo amistad con el zorro que lo lamió."));
        lista.add(new Pregunta(3,"¿Cuál era el tesoro que descubrió?",List.of("Un cofre de monedas","Un mapa antiguo","Una corona de oro","Un diamante"),1,"Encontró un mapa antiguo que conducía al tesoro."));
        return lista;
    }
}