package com.example.apptfg.data.local.entities;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Entidad que guarda el puntaje acumulado y estadísticas de preguntas
 * (solo habrá un registro, con id = 1).
 */
@Entity(tableName = "puntos")
public class Puntos {
    @PrimaryKey
    @NonNull
    private int id = 1;

    private int cantidad;
    private int preguntasRespondidas;
    private int preguntasCorrectas;

    public Puntos(int cantidad, int preguntasRespondidas, int preguntasCorrectas) {
        this.id = 1;
        this.cantidad = cantidad;
        this.preguntasRespondidas = preguntasRespondidas;
        this.preguntasCorrectas = preguntasCorrectas;
    }

    @NonNull
    public int getId() {
        return id;
    }

    // Room necesita este setter para poder asignar el valor de la clave primaria
    public void setId(@NonNull int id) {
        this.id = id;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getPreguntasRespondidas() {
        return preguntasRespondidas;
    }

    public void setPreguntasRespondidas(int preguntasRespondidas) {
        this.preguntasRespondidas = preguntasRespondidas;
    }

    public int getPreguntasCorrectas() {
        return preguntasCorrectas;
    }

    public void setPreguntasCorrectas(int preguntasCorrectas) {
        this.preguntasCorrectas = preguntasCorrectas;
    }
}
