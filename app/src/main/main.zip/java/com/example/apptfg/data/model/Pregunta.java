package com.example.apptfg.data.model;
import java.util.List;
public class Pregunta {
    private final int id; private final String texto; private final List<String> opciones; private final int respuestaCorrecta; private final String explicacion;
    public Pregunta(int id, String texto, List<String> opciones, int respuestaCorrecta, String explicacion) {
        this.id=id; this.texto=texto; this.opciones=opciones; this.respuestaCorrecta=respuestaCorrecta; this.explicacion=explicacion;
    }
    public int getId() { return id; } public String getTexto() { return texto; } public List<String> getOpciones() { return opciones; }
    public int getRespuestaCorrecta() { return respuestaCorrecta; } public String getExplicacion() { return explicacion; }
}