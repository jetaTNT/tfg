package com.example.apptfg.ui.quiz;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.apptfg.R;
import com.example.apptfg.data.model.Pregunta;
import com.example.apptfg.data.model.ResultadoPregunta;
import com.example.apptfg.ui.stats.StatsActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

import java.util.List;

/**
 * Activity que muestra el cuestionario de preguntas una vez finaliza el cuento.
 */
public class PreguntasActivity extends AppCompatActivity {

    public static final String EXTRA_LIBRO_ID = "com.example.apptfg.EXTRA_LIBRO_ID";
    public static final String EXTRA_PAGINA_FINAL_ID = "com.example.apptfg.EXTRA_PAGINA_FINAL_ID";

    private QuizViewModel viewModel;
    private TextView tvPregunta, tvTemporizador;
    private LinearLayout opcionesContainer;
    private ProgressBar progressBar;
    private CountDownTimer timer;

    private int libroId;
    private int paginaFinalId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preguntas);

        // Configurar Toolbar
        MaterialToolbar toolbar = findViewById(R.id.toolbar_quiz);
        toolbar.setTitle(R.string.titulo_quiz);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Obtener referencias a vistas
        tvPregunta = findViewById(R.id.tvPregunta);
        tvTemporizador = findViewById(R.id.tvTemporizador);
        opcionesContainer = findViewById(R.id.opcionesContainer);
        progressBar = findViewById(R.id.progressBarTime);

        // Recuperar datos del Intent
        libroId = getIntent().getIntExtra(EXTRA_LIBRO_ID, -1);
        paginaFinalId = getIntent().getIntExtra(EXTRA_PAGINA_FINAL_ID, -1);
        if (libroId == -1 || paginaFinalId == -1) {
            // Si faltan parámetros, cerramos la Activity
            finish();
            return;
        }

        // Instanciar ViewModel y cargar preguntas
        viewModel = new ViewModelProvider(this).get(QuizViewModel.class);
        viewModel.init(libroId, paginaFinalId);

        // Observar LiveData de preguntas: cuando cargan, mostramos la primera pregunta
        viewModel.getPreguntasLive().observe(this, preguntas -> {
            if (preguntas != null && !preguntas.isEmpty()) {
                mostrarPreguntaActual();
            }
        });

        // Observar LiveData de índice: si cambia, mostramos la nueva pregunta (o terminamos)
        viewModel.getIndicePregunta().observe(this, idx -> mostrarPreguntaActual());
    }

    /**
     * Muestra la pregunta actual según el índice en viewModel.getIndicePregunta().
     * Si el índice se sale de rango, redirecciona a StatsActivity.
     */
    private void mostrarPreguntaActual() {
        List<Pregunta> lista = viewModel.getPreguntasLive().getValue();
        Integer idx = viewModel.getIndicePregunta().getValue();
        if (lista == null || idx == null || idx >= lista.size()) {
            irAEstadisticas();
            return;
        }

        Pregunta p = lista.get(idx);
        tvPregunta.setText(p.getTexto());
        opcionesContainer.removeAllViews();

        // Configurar temporizador de 10 segundos
        if (timer != null) timer.cancel();
        progressBar.setMax(10);
        progressBar.setProgress(10);
        tvTemporizador.setText(getString(R.string.tiempo_restante, 10));

        timer = new CountDownTimer(10000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int seg = (int) (millisUntilFinished / 1000);
                tvTemporizador.setText(getString(R.string.tiempo_restante, seg));
                progressBar.setProgress(seg);
            }

            @Override
            public void onFinish() {
                // Si se agota el tiempo, contamos como “sin responder” y guardamos resultado
                viewModel.responder(-1);
            }
        }.start();

        // Para cada opción, creamos un MaterialButton y lo agregamos al contenedor
        for (int i = 0; i < p.getOpciones().size(); i++) {
            String textoOpcion = p.getOpciones().get(i);
            MaterialButton btn = new MaterialButton(this);
            btn.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            ));
            final int seleccion = i;
            btn.setText(textoOpcion);
            btn.setOnClickListener(v -> {
                deshabilitarTodos();
                timer.cancel();
                viewModel.responder(seleccion);
                mostrarRetroalimentacion();
            });
            opcionesContainer.addView(btn);
        }
    }

    /**
     * Muestra la retroalimentación coloreando el botón correcto,
     * luego, tras un retraso de 1.5s, avanza a la siguiente pregunta o termina.
     */
    private void mostrarRetroalimentacion() {
        List<ResultadoPregunta> res = viewModel.getResultadosLive().getValue();
        List<Pregunta> lista = viewModel.getPreguntasLive().getValue();
        Integer idx = viewModel.getIndicePregunta().getValue();
        if (res == null || lista == null || idx == null) return;

        ResultadoPregunta ultimo = res.get(res.size() - 1);
        Pregunta actual = lista.get(idx);

        // Marcar en verde el botón correcto
        for (int i = 0; i < opcionesContainer.getChildCount(); i++) {
            View v = opcionesContainer.getChildAt(i);
            if (!(v instanceof MaterialButton)) continue;
            MaterialButton b = (MaterialButton) v;
            if (i == actual.getRespuestaCorrecta()) {
                b.setBackgroundColor(getColor(android.R.color.holo_green_light));
            }
        }

        // Tras 1.5 segundos, avanzamos a la siguiente o terminamos
        new Handler().postDelayed(() -> {
            if (viewModel.haySiguiente()) {
                viewModel.avanzarPregunta();
            } else {
                irAEstadisticas();
            }
        }, 1500);
    }

    /** Deshabilita todos los botones de opciones para que no se pueda pulsar más de una vez. */
    private void deshabilitarTodos() {
        for (int i = 0; i < opcionesContainer.getChildCount(); i++) {
            opcionesContainer.getChildAt(i).setEnabled(false);
        }
    }

    /** Redirige a la pantalla de estadísticas y cierra esta Activity. */
    private void irAEstadisticas() {
        Intent i = new Intent(this, StatsActivity.class);
        startActivity(i);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) timer.cancel();
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
