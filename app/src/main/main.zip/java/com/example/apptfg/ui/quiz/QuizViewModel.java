package com.example.apptfg.ui.quiz;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.apptfg.data.local.AppDatabase;
import com.example.apptfg.data.local.dao.PuntosDao;
import com.example.apptfg.data.local.entities.Puntos;
import com.example.apptfg.data.model.Pregunta;
import com.example.apptfg.data.model.ResultadoPregunta;
import com.example.apptfg.repository.PreguntaRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ViewModel para PreguntasActivity:
 * - expone LiveData<List<Pregunta>>
 * - expone LiveData<Integer> para el índice de la pregunta actual
 * - expone LiveData<List<ResultadoPregunta>> para ir guardando los resultados
 * - contiene la lógica de avanzar pregunta y actualizar puntos en la base de datos
 */
public class QuizViewModel extends AndroidViewModel {

    private final PreguntaRepository preguntaRepo;
    private final PuntosDao puntosDao;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    // LiveData con la lista de preguntas
    private final MutableLiveData<List<Pregunta>> preguntasLive = new MutableLiveData<>();
    // LiveData con el índice actual (inicia en 0)
    private final MutableLiveData<Integer> indicePregunta = new MutableLiveData<>(0);
    // LiveData con la lista de resultados de cada pregunta (acierto/fallo)
    private final MutableLiveData<List<ResultadoPregunta>> resultadosLive = new MutableLiveData<>(new ArrayList<>());

    public QuizViewModel(@NonNull Application application) {
        super(application);
        preguntaRepo = PreguntaRepository.getInstance();
        puntosDao = AppDatabase.getInstance(application).puntosDao();
    }

    /**
     * Inicializa el ViewModel: carga las preguntas desde el repositorio (background thread)
     * @param libroId ID del libro que acabamos de leer
     * @param paginaFinalId ID de la página final (usado para filtrar preguntas)
     */
    public void init(int libroId, int paginaFinalId) {
        executor.execute(() -> {
            List<Pregunta> lista = preguntaRepo.getPreguntasParaPaginaFinal(libroId, paginaFinalId);
            preguntasLive.postValue(lista);
        });
    }

    /** LiveData que expone la lista de preguntas. */
    public LiveData<List<Pregunta>> getPreguntasLive() {
        return preguntasLive;
    }

    /** LiveData que expone el índice de la pregunta actual. */
    public LiveData<Integer> getIndicePregunta() {
        return indicePregunta;
    }

    /** LiveData con los resultados de cada pregunta (se va quedando en memoria la lista). */
    public LiveData<List<ResultadoPregunta>> getResultadosLive() {
        return resultadosLive;
    }

    /**
     * Llamado cuando el usuario responde una pregunta:
     *  - Calcula si la respuesta es correcta
     *  - Agrega un ResultadoPregunta a resultadosLive
     *  - Actualiza la tabla Puntos (incrementa preguntarap. y correctas si acertó)
     *  - Avanza índice de pregunta si queda alguna
     * @param seleccion índice escogido por el usuario (0..n-1). Si es -1, significa que no respondió a tiempo.
     */
    public void responder(int seleccion) {
        List<Pregunta> lista = preguntasLive.getValue();
        Integer idx = indicePregunta.getValue();
        if (lista == null || idx == null || idx >= lista.size()) return;

        Pregunta actual = lista.get(idx);
        boolean acertada = (seleccion == actual.getRespuestaCorrecta());

        // 1) Guardar resultado en memoria (para que la UI lo observe y responda)
        List<ResultadoPregunta> resCurrent = resultadosLive.getValue();
        if (resCurrent == null) resCurrent = new ArrayList<>();
        resCurrent.add(new ResultadoPregunta(actual.getId(), acertada));
        resultadosLive.postValue(resCurrent);

        // 2) Actualizar la base de datos de Puntos (background thread)
        executor.execute(() -> {
            Puntos pts = puntosDao.obtenerPuntosSincrono();
            if (pts != null) {
                // Incrementar preguntas respondidas
                pts.setPreguntasRespondidas(pts.getPreguntasRespondidas() + 1);
                if (acertada) {
                    // Incrementar correctas y sumar 10 puntos al total
                    pts.setPreguntasCorrectas(pts.getPreguntasCorrectas() + 1);
                    pts.setCantidad(pts.getCantidad() + 10);
                }
                puntosDao.updatePuntos(pts);
            }
        });

        // 3) Avanzar internamente al siguiente índice si hay más preguntas
        if (idx + 1 < lista.size()) {
            // Usamos postValue en background thread para que LiveData lo notifique en main thread
            indicePregunta.postValue(idx + 1);
        }
        // Si no hay siguiente, dejaremos que la Activity detecte fin al observar indice.
    }

    /**
     * Método público para avanzar a la siguiente pregunta.
     * Esto evita que la Activity intente hacer `setValue` en un LiveData protegido.
     */
    public void avanzarPregunta() {
        Integer idx = indicePregunta.getValue();
        List<Pregunta> lista = preguntasLive.getValue();
        if (idx != null && lista != null && idx + 1 < lista.size()) {
            indicePregunta.setValue(idx + 1);
        }
    }

    /**
     * Indica si hay una pregunta siguiente a la actual.
     * @return true si (índice actual + 1) < tamaño de lista de preguntas.
     */
    public boolean haySiguiente() {
        List<Pregunta> lista = preguntasLive.getValue();
        Integer idx = indicePregunta.getValue();
        return lista != null && idx != null && (idx + 1) < lista.size();
    }
}
