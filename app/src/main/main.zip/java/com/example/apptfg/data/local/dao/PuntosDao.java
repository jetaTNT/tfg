package com.example.apptfg.data.local.dao;
import androidx.lifecycle.LiveData;import androidx.room.Dao;import androidx.room.Insert;import androidx.room.OnConflictStrategy;import androidx.room.Query;import androidx.room.Update;
import com.example.apptfg.data.local.entities.Puntos;
@Dao
public interface PuntosDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE) void insertPuntos(Puntos puntos);
    @Update void updatePuntos(Puntos puntos);
    @Query("SELECT * FROM puntos WHERE id = 1") LiveData<Puntos> obtenerPuntosLive();
    @Query("SELECT * FROM puntos WHERE id = 1") Puntos obtenerPuntosSincrono();
}