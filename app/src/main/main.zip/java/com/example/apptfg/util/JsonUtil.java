package com.example.apptfg.util;
import android.content.Context;import com.google.gson.Gson;import java.io.InputStreamReader;import java.io.IOException;
public class JsonUtil {
    public static <T> T loadFromAsset(Context context, String assetPath, Class<T> clazz) {
        try (InputStreamReader reader = new InputStreamReader(context.getAssets().open(assetPath))) {
            return new Gson().fromJson(reader, clazz);
        } catch (IOException e) {
            e.printStackTrace(); return null;
        }
    }
}