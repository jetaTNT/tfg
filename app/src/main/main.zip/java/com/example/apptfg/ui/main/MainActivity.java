package com.example.apptfg.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.apptfg.R;
import com.example.apptfg.data.model.Libro;
import com.example.apptfg.ui.lector.LectorActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.snackbar.Snackbar;

import java.util.List;

public class MainActivity extends AppCompatActivity implements LibrosAdapter.OnLibroClickListener {

    private MainViewModel viewModel;
    private LibrosAdapter adapter;
    private TextView tvPuntos;
    private RecyclerView rvLibros;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Configurar Toolbar
        MaterialToolbar toolbar = findViewById(R.id.toolbar_main);
        toolbar.setTitle(getString(R.string.titulo_main));
        setSupportActionBar(toolbar);

        // Obtener referencias a vistas
        tvPuntos = findViewById(R.id.tvPuntosMain);
        rvLibros = findViewById(R.id.rvLibros);

        // Instanciar ViewModel
        viewModel = new ViewModelProvider(this).get(MainViewModel.class);

        // Configurar RecyclerView y Adapter
        adapter = new LibrosAdapter(this);
        rvLibros.setLayoutManager(new LinearLayoutManager(this));
        rvLibros.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
        rvLibros.setAdapter(adapter);

        // Observar lista de libros
        viewModel.getListaLibros().observe(this, libros -> {
            if (libros == null || libros.isEmpty()) {
                Snackbar.make(rvLibros, R.string.no_libros_disponibles, Snackbar.LENGTH_LONG).show();
            } else {
                adapter.submitList(libros);
            }
        });

        // Observar puntos acumulados
        viewModel.getPuntosLive().observe(this, puntos -> {
            if (puntos != null) {
                tvPuntos.setText(getString(R.string.puntos_main, puntos.getCantidad()));
            }
        });
    }

    @Override
    public void onLibroClick(Libro libro) {
        Intent intent = new Intent(this, LectorActivity.class);
        intent.putExtra(LectorActivity.EXTRA_LIBRO_ID, libro.getId());
        startActivity(intent);
    }
}
