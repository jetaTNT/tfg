package com.example.apptfg.ui.lector;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.apptfg.R;
import com.example.apptfg.data.model.Pagina;
import com.example.apptfg.data.model.Opcion;
import com.example.apptfg.ui.quiz.PreguntasActivity;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

import java.util.List;

/**
 * Activity que muestra las páginas de un libro interactivo.
 */
public class LectorActivity extends AppCompatActivity {

    public static final String EXTRA_LIBRO_ID = "com.example.apptfg.EXTRA_LIBRO_ID";

    private ReaderViewModel viewModel;
    private TextView tvTextoPagina, tvPuntos;
    private LinearLayout opcionesContainer;
    private MaterialButton btnVerPreguntas;

    private int libroId;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lector);

        MaterialToolbar toolbar = findViewById(R.id.toolbar_lector);
        toolbar.setTitle(R.string.titulo_lector);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tvPuntos = findViewById(R.id.tvPuntosLector);
        tvTextoPagina = findViewById(R.id.tvTextoPagina);
        opcionesContainer = findViewById(R.id.opcionesContainer);
        btnVerPreguntas = findViewById(R.id.btnVerPreguntas);
        btnVerPreguntas.setVisibility(View.GONE);

        libroId = getIntent().getIntExtra(EXTRA_LIBRO_ID, -1);
        if (libroId == -1) {
            finish();
            return;
        }

        viewModel = new ViewModelProvider(this).get(ReaderViewModel.class);
        viewModel.init(libroId);

        viewModel.getPaginaActual().observe(this, this::renderPagina);

        btnVerPreguntas.setOnClickListener(v -> {
            Pagina actual = viewModel.getPaginaActual().getValue();
            if (actual != null && actual.esPaginaFinal()) {
                Intent i = new Intent(this, PreguntasActivity.class);
                i.putExtra(PreguntasActivity.EXTRA_LIBRO_ID, libroId);
                i.putExtra(PreguntasActivity.EXTRA_PAGINA_FINAL_ID, actual.getId());
                startActivity(i);
                finish();
            }
        });
    }

    private void renderPagina(Pagina pagina) {
        if (pagina == null) return;

        tvTextoPagina.setText(pagina.getTexto());
        opcionesContainer.removeAllViews();
        btnVerPreguntas.setVisibility(View.GONE);

        List<Opcion> opciones = pagina.getOpciones();
        if (opciones.isEmpty()) {
            // Página final: mostrar botón "Ver preguntas"
            btnVerPreguntas.setVisibility(View.VISIBLE);
            viewModel.registrarPaginaFinal(5); // Ejemplo: 5 puntos de bonificación
        } else {
            for (Opcion op : opciones) {
                // Crear un MaterialButton con estilo por defecto de MaterialComponents
                MaterialButton btn = new MaterialButton(this);
                btn.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                btn.setText(op.getTexto());
                btn.setOnClickListener(v -> {
                    deshabilitarOpciones();
                    viewModel.elegirOpcion(op);
                });
                opcionesContainer.addView(btn);
            }
        }
    }

    private void deshabilitarOpciones() {
        int count = opcionesContainer.getChildCount();
        for (int i = 0; i < count; i++) {
            opcionesContainer.getChildAt(i).setEnabled(false);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}
