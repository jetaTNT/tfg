package com.example.apptfg.repository;
import android.content.Context;import androidx.lifecycle.LiveData;import androidx.lifecycle.MutableLiveData;import com.example.apptfg.data.model.Libro;import com.example.apptfg.util.JsonUtil;import java.util.ArrayList;import java.util.List;import java.util.concurrent.ExecutorService;import java.util.concurrent.Executors;
public class LibroRepository {
    private static LibroRepository INSTANCE;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final MutableLiveData<List<Libro>> librosLive = new MutableLiveData<>();
    private LibroRepository(Context context) { cargarLibrosDesdeAssets(context); }
    public static synchronized LibroRepository getInstance(Context context) {
        if (INSTANCE == null) { INSTANCE = new LibroRepository(context); }
        return INSTANCE;
    }
    private void cargarLibrosDesdeAssets(Context context) {
        executor.execute(() -> {
            List<Libro> lista = new ArrayList<>();
            Libro libro1 = JsonUtil.loadFromAsset(context, "books/libro1.json", Libro.class);
            if (libro1 != null) lista.add(libro1);
            librosLive.postValue(lista);
        });
    }
    public LiveData<List<Libro>> getLibrosLive() { return librosLive; }
    public Libro getLibroPorId(int id) {
        List<Libro> lista = librosLive.getValue();
        if (lista == null) return null;
        for (Libro l : lista) { if (l.getId() == id) return l; }
        return null;
    }
}