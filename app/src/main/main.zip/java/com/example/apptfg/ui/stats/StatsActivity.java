package com.example.apptfg.ui.stats;
import android.os.Bundle;import android.widget.TextView;import android.widget.Button;import androidx.annotation.Nullable;import androidx.appcompat.app.AppCompatActivity;import androidx.lifecycle.ViewModelProvider;import com.example.apptfg.R;import com.google.android.material.appbar.MaterialToolbar;
public class StatsActivity extends AppCompatActivity {
    private StatsViewModel viewModel; private TextView tvTotalPuntos, tvRespondidas, tvCorrectas, tvIncorrectas; private Button btnVolver;
    @Override protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_stats);
        MaterialToolbar toolbar = findViewById(R.id.toolbar_stats); toolbar.setTitle(R.string.titulo_stats); setSupportActionBar(toolbar); getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        tvTotalPuntos = findViewById(R.id.tvTotalPuntos); tvRespondidas = findViewById(R.id.tvPreguntasRespondidas); tvCorrectas = findViewById(R.id.tvPreguntasCorrectas); tvIncorrectas = findViewById(R.id.tvPreguntasIncorrectas); btnVolver = findViewById(R.id.btnVolverStats);
        viewModel = new ViewModelProvider(this).get(StatsViewModel.class);
        viewModel.getPuntosLive().observe(this, puntos -> {
            if (puntos!=null) {
                tvTotalPuntos.setText(getString(R.string.total_puntos,puntos.getCantidad()));
                tvRespondidas.setText(getString(R.string.respondidas,puntos.getPreguntasRespondidas()));
                tvCorrectas.setText(getString(R.string.correctas,puntos.getPreguntasCorrectas()));
                int incorrectas = puntos.getPreguntasRespondidas()-puntos.getPreguntasCorrectas();
                tvIncorrectas.setText(getString(R.string.incorrectas,incorrectas));
            }
        });
        btnVolver.setOnClickListener(v -> finish());
    }
    @Override public boolean onSupportNavigateUp() { finish(); return true; }
}