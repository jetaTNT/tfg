package com.example.apptfg.ui.main;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.apptfg.data.local.AppDatabase;
import com.example.apptfg.data.local.dao.PuntosDao;
import com.example.apptfg.data.local.entities.Puntos;
import com.example.apptfg.data.model.Libro;
import com.example.apptfg.repository.LibroRepository;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * ViewModel para MainActivity:
 * - Carga la lista de libros (LiveData<List<Libro>>)
 * - Expone LiveData<Puntos> con los puntos acumulados
 * - Se encarga de inicializar el registro de Puntos en background si no existe
 */
public class MainViewModel extends AndroidViewModel {

    private final LibroRepository libroRepo;
    private final PuntosDao puntosDao;
    private final LiveData<List<Libro>> listaLibros;
    private final LiveData<Puntos> puntosLive;
    // Un único hilo para operaciones en BD
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public MainViewModel(@NonNull Application application) {
        super(application);
        // 1) Inicializar repositorio de Libros
        libroRepo = LibroRepository.getInstance(application);
        listaLibros = libroRepo.getLibrosLive();

        // 2) Inicializar DAO de Puntos y LiveData<Puntos>
        AppDatabase db = AppDatabase.getInstance(application);
        puntosDao = db.puntosDao();
        puntosLive = puntosDao.obtenerPuntosLive();

        // 3) Comprobar en background si existe registro de Puntos (id=1) y crearlo si no
        executor.execute(() -> {
            Puntos existing = puntosDao.obtenerPuntosSincrono();
            if (existing == null) {
                // Si no hay registro, insertamos uno inicial (0 puntos, 0 respondidas, 0 correctas)
                puntosDao.insertPuntos(new Puntos(0, 0, 0));
            }
        });
    }

    /**
     * Devuelve LiveData con la lista de libros cargados desde JSON en assets.
     */
    public LiveData<List<Libro>> getListaLibros() {
        return listaLibros;
    }

    /**
     * Devuelve LiveData con los puntos acumulados,
     * preguntas respondidas y correctas.
     */
    public LiveData<Puntos> getPuntosLive() {
        return puntosLive;
    }
}
